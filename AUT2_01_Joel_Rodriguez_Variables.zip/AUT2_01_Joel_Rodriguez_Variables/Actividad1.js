
function actividad1() {
    var number = 15;
    for (var i = 0; i <= 6; i++) {
        number *= number
    };
    alert(number);
}