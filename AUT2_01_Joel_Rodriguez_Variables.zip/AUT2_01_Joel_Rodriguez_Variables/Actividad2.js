function actividad2() {
    let add = 0;
    for (let i = 1; i <= 10; i++) {
        add += i;
    }
    alert(add);
}