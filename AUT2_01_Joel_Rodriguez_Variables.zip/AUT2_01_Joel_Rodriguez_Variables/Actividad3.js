function actividad3() {
    for (let i = 0; i <= 9; i++) {
        console.log(i);
        for (let j = 0; j <= 9; j++) {
            console.log(j);
        }
    }
}