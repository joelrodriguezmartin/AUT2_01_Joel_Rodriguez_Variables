function actividad4() {
    let number1 = document.getElementById("number1").value;
    let number2 = document.getElementById("number2").value;
    let number3 = document.getElementById("number3").value;

    console.log(number1++ + " -> " + number1)
    console.log(number2++ + " -> " + number2)
    console.log(number3++ + " -> " + number3)
}