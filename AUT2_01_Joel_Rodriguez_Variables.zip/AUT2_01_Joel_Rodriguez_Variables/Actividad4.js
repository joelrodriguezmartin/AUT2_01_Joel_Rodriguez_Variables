function actividad4() {
    let number1 = parseInt(window.prompt("Introduzca el primer numero"));
    let number2 = parseInt(window.prompt("Introduzca el segundo numero"));
    let number3 = parseInt(window.prompt("Introduzca el tercer numero"));

    console.log(number1++ + " -> " + number1)
    console.log(number2++ + " -> " + number2)
    console.log(number3++ + " -> " + number3)
}