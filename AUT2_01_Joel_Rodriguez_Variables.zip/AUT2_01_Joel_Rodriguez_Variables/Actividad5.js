function actividad5() {
    for (let i = 0; i < 5; i++) {
        suma1 = parseInt(window.prompt("Introduzca el primer numero: "));
        suma2 = parseInt(window.prompt("Introduzca el segundo numero: "));

        console.log(suma1 + suma2);
    }
}