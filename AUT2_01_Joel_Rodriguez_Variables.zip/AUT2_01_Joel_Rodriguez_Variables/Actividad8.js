function actividad8() {
    let number = parseInt(window.prompt("Introduzca un numero"));
    if (number % 2 == 0) {
        alert("Es par");
    }
    else {
        alert("Es impar");
    }
}