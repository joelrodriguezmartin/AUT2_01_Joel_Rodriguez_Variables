function actividad3(){
    for(let i = 0, j = 20; i < 8 && j > 0; i++, j-=3){   
        console.log(i,j)
    }
}